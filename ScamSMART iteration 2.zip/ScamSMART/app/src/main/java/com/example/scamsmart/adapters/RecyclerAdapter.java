package com.example.scamsmart.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.scamsmart.R;
import com.example.scamsmart.models.Post;
import com.example.scamsmart.ui.block_activity;

import java.util.List;

public class RecyclerAdapter  extends RecyclerView.Adapter<RecyclerAdapter.MyViewHolder> {


    //From https://www.youtube.com/watch?v=FFCpjZkqfb0

    List<Post> postList;
    Context context;

    public RecyclerAdapter(List<Post> postList, Context context) {
        this.postList = postList;
        this.context = context;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        TextView tvUsername;
        TextView tvNumber;
        Button btnBlock;
        EditText etDescription;
        ConstraintLayout parentLayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            tvUsername = itemView.findViewById(R.id.tvUser);
            tvNumber = itemView.findViewById(R.id.tvNumber);
            btnBlock = itemView.findViewById(R.id.btnBlock);
            etDescription = itemView.findViewById(R.id.etDesc);
            parentLayout = itemView.findViewById(R.id.row);

        }
    }



    @NonNull
    @Override
    public RecyclerAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row,parent,false);
        RecyclerAdapter.MyViewHolder holder = new RecyclerAdapter.MyViewHolder(view);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerAdapter.MyViewHolder holder, int position) {

        holder.tvUsername.setText(postList.get(position).getUsername());
        holder.tvNumber.setText(postList.get(position).getNumber());
        holder.etDescription.setText(postList.get(position).getDescription());
        holder.btnBlock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //This passes the number to the blocking activity
                Intent intent = new Intent(context, block_activity.class);
                intent.putExtra("Number", postList.get(position).getNumber());


                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return postList.size();
    }


}
