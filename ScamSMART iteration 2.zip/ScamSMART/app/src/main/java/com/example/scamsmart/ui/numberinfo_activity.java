package com.example.scamsmart.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.scamsmart.R;

public class numberinfo_activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_numberinfo_activity);
    }
}