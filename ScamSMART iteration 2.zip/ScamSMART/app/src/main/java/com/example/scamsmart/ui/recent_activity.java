package com.example.scamsmart.ui;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.EditText;

import com.example.scamsmart.R;
import com.example.scamsmart.adapters.RecyclerAdapter;
import com.example.scamsmart.models.Post;

import java.util.ArrayList;
import java.util.List;

public class recent_activity extends AppCompatActivity {


    //Setting up recyclerview, adapted from https://www.youtube.com/watch?v=FFCpjZkqfb0
    RecyclerView rvPostList;
    RecyclerView.Adapter rvAdapter;
    RecyclerView.LayoutManager layoutManager;
    List<Post> postList = new ArrayList<Post>();
    EditText etDesc;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recent_activity);




        //Displaying recyclerview
        rvPostList = (RecyclerView)findViewById(R.id.rvPosts);
        rvPostList.setHasFixedSize(true);

        layoutManager = new LinearLayoutManager(this);
        rvPostList.setLayoutManager(layoutManager);
        postList = getPosts();
        rvAdapter = new RecyclerAdapter(postList,this);
        rvPostList.setAdapter(rvAdapter);
        etDesc = findViewById(R.id.etDesc);







    }

    public List<Post> getPosts() {
        List<Post> postList = new ArrayList<Post>();
        Post p1 = new Post(1,"Phone Call, claimed to be from Microsoft, tried to get my credit card details","GDonal","0860000000");
        Post p2 = new Post(2,"Text Message, had a link which was a fake version of the AIB website","FRegan","0870000000");
        Post p3 = new Post(3,"Phone Call, tried to get me to invest in their new currency","BDiarmuid","0880000000");
        Post p4 = new Post(4,"Received a text with a link to UPS tracking saying I had to claim my package. Fake website","GYaznen","0890000000");
        postList.add(p1);
        postList.add(p2);
        postList.add(p3);
        postList.add(p4);


        //To show an extra post from the report activity
        if(getIntent().hasExtra("Number")){
            String number = getIntent().getExtras().getString("Number");
            String description = getIntent().getExtras().getString("Description");
            String user = getIntent().getExtras().getString("User");

            Post p5 = new Post(5,description,user,number);

            postList.add(p5);



        }

        return postList;

    }
}