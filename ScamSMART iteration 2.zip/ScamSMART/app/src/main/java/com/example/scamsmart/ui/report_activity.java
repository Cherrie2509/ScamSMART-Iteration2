package com.example.scamsmart.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.scamsmart.R;

public class report_activity extends AppCompatActivity {
    String Number;
    String Description;
    String username;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_activity);

        Button btnReportNumber = findViewById(R.id.btnReportNumber);
        EditText etScamNumber = findViewById(R.id.etScamNumber);
        EditText etDescription = findViewById(R.id.etDescription);





        //Calling the posts activity and passing the details over
        btnReportNumber.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Number = etScamNumber.getText().toString();
                username = "CDing";
                Description = etDescription.getText().toString();

                Intent startintent = new Intent(report_activity.this,recent_activity.class);
                startintent.putExtra("Number",Number);
                startintent.putExtra("User",username);
                startintent.putExtra("Description",Description);

                startActivity(startintent);
            }
        });

    }
}